#!/bin/bash
SESSION_PATH=cs-d37699a40e0886dcd13eab75
# Normalize so bot-relative session dirs survive the script's own cd. The
# invocation contract (the plugin, and `bash start-webapp.sh` from the root)
# always runs with the session dir as cwd, so the cwd fallback is safe.
SESSION_PATH="$(cd "$SESSION_PATH" 2>/dev/null && pwd || pwd)"
PORT=3011

# A record of the reserved port for tooling/debugging (onyx-template parity:
# onyx's template dev script reads it; a generic scaffold ignores it).
echo $PORT > "$SESSION_PATH/.nextjs-port"

(
    set -e
    trap 'echo "bootstrap failed - read the error above, fix, and re-run bash start-webapp.sh" >&2' ERR

    # Replay safety: serialize the check-and-spawn so two starts (a timed-out
    # one beside its retry) can't both spawn a second dev server.
    flock -x 9

    # onyx's scaffold semantics, restored: the template ships with the session
    # (materialized under .openbot/web-template by the managed-content push)
    # instead of a template baked into the sandbox image.
    if [ ! -f "$SESSION_PATH/outputs/web/package.json" ]; then
        if [ -f "$SESSION_PATH/.openbot/web-template/package.json" ]; then
            echo "Copying outputs template"
            mkdir -p "$SESSION_PATH/outputs"
            cp -R "$SESSION_PATH/.openbot/web-template" "$SESSION_PATH/outputs/web"
        else
            echo "no web app scaffold found - build your web app under outputs/web first (outputs/web/package.json), then call webapp start again" >&2
            exit 1
        fi
    fi

    NEXTJS_PID=""
    if [ -f "$SESSION_PATH/nextjs.pid" ]; then
        NEXTJS_PID="$(cat "$SESSION_PATH/nextjs.pid")"
    fi
    # Identity guard: kill -0 alone trusts a recycled pid. A stale
    # nextjs.pid could name an unrelated live process — skip the spawn
    # forever, and the plugin's restart arm would kill that process — so
    # reuse a pid only if its cwd is this session's app dir (onyx's
    # readlink /proc/$pid/cwd comparison).
    if [ -n "$NEXTJS_PID" ] && kill -0 "$NEXTJS_PID" 2>/dev/null && \
       [ "$(readlink /proc/$NEXTJS_PID/cwd 2>/dev/null)" = "$SESSION_PATH/outputs/web" ]; then
        echo "Next.js server already running (PID $NEXTJS_PID); reusing"
    else
        # Stale, dead, or mismatched: drop the pid file before respawning so
        # a dead pid never outlives this run.
        rm -f "$SESSION_PATH/nextjs.pid"
        cd "$SESSION_PATH/outputs/web"
        # bun's install tempdir follows BUN_INSTALL when the image sets it
        # (agent-sandbox exports BUN_INSTALL=/usr/local, root-owned), which
        # fails install with AccessDenied — pin the cache under $HOME unless
        # the deployment already chose one.
        export BUN_INSTALL_CACHE_DIR="${BUN_INSTALL_CACHE_DIR:-$HOME/.bun/install-cache}"
        # Not [ -d node_modules ]: a failed install leaves an empty directory
        # behind, and rerunning would skip straight to a spawn with no bins.
        if [ ! -x node_modules/.bin/next ]; then
            echo "Installing dependencies with bun..."
            bun install
        fi
        echo "Starting Next.js dev server on port $PORT..."
        # 9>&-: the server must not inherit the lock fd, or it would hold the
        # check-and-spawn lock for its entire lifetime. -H 0.0.0.0 is onyx's own
        # bind: the preview dials this port on the sandbox host (F-E), not the
        # container's private loopback.
        PORT="$PORT" nohup bun run dev -- -H 0.0.0.0 -p "$PORT" \
            > "$SESSION_PATH/nextjs.log" 2>&1 9>&- &
        NEXTJS_PID=$!
        echo "Next.js server started with PID $NEXTJS_PID"
        echo $NEXTJS_PID > "$SESSION_PATH/nextjs.pid"
    fi
) 9>"$SESSION_PATH/.webapp.lock"
if [ "$?" -ne 0 ]; then
    exit 1
fi

echo "Waiting for the dev server to become ready..."
DEADLINE=$((SECONDS + 90))
while [ "$SECONDS" -lt "$DEADLINE" ]; do
    if curl -s -o /dev/null --noproxy '*' --max-time 2 "http://127.0.0.1:$PORT/"; then
        echo "web app dev server running on port $PORT - app dir: outputs/web, logs: nextjs.log. It hot-reloads on file changes and never needs 'bun run dev' run by hand."
        exit 0
    fi
    sleep 1
done

echo "server did not become ready - check nextjs.log; if it crashed, fix the error and re-run bash start-webapp.sh" >&2
echo "--- last 30 lines of nextjs.log ---" >&2
tail -n 30 "$SESSION_PATH/nextjs.log" 2>/dev/null >&2 || true
exit 1
